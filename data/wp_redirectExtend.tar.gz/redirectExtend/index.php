<?php
/*
  Plugin Name: Redirects extended
  Plugin URI: http://www.trafficjunction.co.uk/
  Description: CouponPress extend
  Version: 1.0
  Author: Maksym Trofimenko
  Author URI: http://tpoxa.com
 */


// create custom plugin settings menu
add_action('admin_menu', 'redirects_create_menu');

function redirects_create_menu() {

    //create new top-level menu
    add_options_page('redirects Plugin Settings', 'Redirects Settings', 'administrator', __FILE__, 'redirects_settings_page');

    //call register settings function
    add_action('admin_init', 'register_mysettings');
}

function register_mysettings() {
    //register our settings
    add_meta_box('myplugin_sectionid', __('Parametrized URL', 'myplugin_textdomain'), 'myplugin_inner_custom_box', 'post', 'advanced', 'high');

    register_setting('redirects-settings-group', 'redirect_rules');
    register_setting('redirects-settings-group', 'redirectsMagicParam');
}

function myplugin_inner_custom_box() {
    global $post;

    //print_r($post);
    $permalink = get_permalink();
    $mp = get_option('redirectsMagicParam');

    echo '<input type="text" size="80" value="' . addmagicParam($permalink, $mp) . '"/>';
}

function redirects_settings_page() {
    ?>
    <div class="wrap">
        <h2>Redirects extended options</h2>

        <form method="post" action="options.php">
            <?php settings_fields('redirects-settings-group'); ?>
            <?php // do_settings('redirects-settings-group'); ?>
            <table class="form-table" style="width:530px" id="rowsList">
                <tr valign="top">
                    <th scope="row">Magic Parameter</th>
                    <td><input type="text" name="redirectsMagicParam" value="<?php echo get_option('redirectsMagicParam'); ?>" /></td>
                    <td></td>
                </tr>
                <tr>
                    <td  colspan="3" style="text-align: center"><h3>Website URL parsing rule</h3></td>
                </tr>

                <?php
                $domailRules = get_option('redirect_rules');

                if (is_array($domailRules)):
                    foreach ($domailRules as $domain => $rule):
                        ?>
                        <tr>
                            <td>
                                <?php echo $domain; ?>
                            </td>
                            <td>
                                <textarea  name="redirect_rules[<?php echo $domain; ?>]" placeholder="new domain rule"  cols="36"><?php echo $rule; ?></textarea>
                            </td>
                            <td>
                                <button class="rmvBrn">x</button>
                            </td>
                        </tr>

                        <?php
                    endforeach;
                endif;
                ?>

            </table>
            <table class="form-table" style="width:530px">
                <tr>
                    <td>
                        <input type="text" id="newDomain" placeholder="new domain" size="16"/>
                    </td>
                    <td>
                        <textarea  id="newDomainRule" placeholder="new domain rule"  cols="26"></textarea>
                    </td>
                    <td>
                        <button id="addRule">Add</button>
                    </td>
                </tr>
            </table>    

            <script type="text/javascript">
                                                        
                jQuery(document).ready(function($){
                    $("#addRule").click(function(e){
                        e.preventDefault();
                        var domain = $("#newDomain").val();
                        var rule = $("#newDomainRule").val();
                                                                
                        var tr = $("<tr/>");
                        tr.append($("<td/>").append(domain));
                        tr.append($("<td/>").html(
                        $('<input type="text" size="35"/>').attr("name", "redirect_rules["+ domain +"]").val(rule)
                    ));
                        tr.append($("<td/>").append($("<button/>").addClass("rmvBtn").html("x")));
                                                                
                        $("#rowsList").append(tr);                          
                        $("#newDomain").val('');
                        $("#newDomainRule").val('');
                    });
                                                      
                    $(".rmvBrn").live('click',function(){
                        $(this).parents("tr").remove();
                                                        
                    })  
                });
                                                
            </script>

            <p class="submit">
                <input type="submit" class="button-primary" value="<?php _e('Save Changes') ?>" />
            </p>

        </form>
    </div>
    <?php
}

add_action('template_redirect', 'redirects_field_redirect');

function addmagicParam($url, $mp) {

    if (strpos($url, '?') !== false)
        return $url . '&' . $mp;

    return $url . '?' . $mp;
}

function redirects_field_redirect() {
    //globalize vars
    global $wp_query, $post;


    $mp = get_option('redirectsMagicParam');
    $redirectUrl = get_post_meta($wp_query->post->ID, 'link', true);

    $referer = wp_get_referer();
    $permalink = get_permalink();

    if (strpos($referer, $permalink) !== false && $referer == addmagicParam($permalink, $mp)) {
        clientSideRedirect($redirectUrl);
        return;
    }

    if (isset($_GET[$mp]) && is_singular()) {
        clientSideRedirect($permalink);
        return;
    }
}

function clientSideRedirect($url) {
    $url = getTarget($url);
    ?>
    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US">
        <head>
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

            <script type="text/javascript">
                function redirectTo(){
                    //alert('<?php echo $url; ?>');
                    window.location.href = '<?php echo $url; ?>';                              
                }
                                                            
            </script>
        </head>
        <body onload="redirectTo();"></body>

    </html>
    <?php
    die;
}

function getTarget($url) {

    $parts = parse_url($url);
    if (isset($parts['host'])) {
        $host = $parts['host'];
        $domailRules = get_option('redirect_rules');

        if (isset($domailRules[$host])) {
            $pattern = $domailRules[$host];
            $html = fetchPage($url);
            if (preg_match($pattern, $html, $matches)) {

                return isset($matches[1]) ? $matches[1] : $url;
            }
        }
    }

    return $url;
}

function fetchPage($url) {
    /*
      // could shoud be faster
      if (function_exists('curl_init')) {

      $ch = curl_init();
      $timeout = 5;
      curl_setopt($ch, CURLOPT_URL, $url);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
      $html = curl_exec($ch);
      curl_close($ch);
      return $html;
      }
     */
    return file_get_contents($url);
}